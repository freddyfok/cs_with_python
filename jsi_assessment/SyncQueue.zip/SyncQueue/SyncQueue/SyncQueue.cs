﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

namespace VbUcmTest
{
	/// <summary>
	/// A synchronized producer-consumer queue that allows any number of
	/// threads to enqueue or dequeue items.
	/// </summary>
	/// <typeparam name="T">The type of item on the queue.</typeparam>
	public class SyncQueue<T>
	{
		private AutoResetEvent newItemEvent = new AutoResetEvent(false);
		private Queue<T> internalQueue = new Queue<T>();

		/// <summary>
		/// Enqueue's an item on the queue.
		/// </summary>
		/// <param name="t">The item to enqueue.</param>
		public void Enqueue(T t)
		{
			// Enqueue the item (thread safe)
			lock (((ICollection)internalQueue).SyncRoot)
			{
				internalQueue.Enqueue(t);
			}
			// Indicate that a new item is available
			newItemEvent.Set();
		}

		/// <summary>
		/// Dequeue's an item from the queue.
		/// </summary>
		/// <remarks>
		/// This call will block the calling thread until an item is available
		/// or the specified timeout is reached.
		/// </remarks>
		/// <param name="t">Returns the dequeued item if the return value is true.</param>
		/// <param name="timeout">The amount of time to wait for an item in milliseconds.</param>
		/// <returns>True if an item was dequeued, false if the timeout was reached.</returns>
		public bool Dequeue(out T t, int timeout)
		{
			// Wait for a new item to be available
			if (newItemEvent.WaitOne(timeout, false))
			{
				// Dequeue the item (thread safe) and return true
				lock (((ICollection)internalQueue).SyncRoot)
				{
					t = internalQueue.Dequeue();
				}
				return true;
			}

			// We timed out.
			t = default(T);
			return false;
		}
	}
}
