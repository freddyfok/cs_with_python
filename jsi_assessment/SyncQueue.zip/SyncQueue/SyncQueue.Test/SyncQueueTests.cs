﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VbUcmTest;
using System.Threading;
using System.Collections.Generic;

namespace SyncQueue.Test
{
    [TestClass]
    public class SyncQueueTests
    {
        /// <summary>
        /// Test to ensure all the items posted to the queue can be dequeued
        /// </summary>
        [TestMethod]
        public void EnsureAllItemsAreDequeued()
        {
            SyncQueue<int> queue = new SyncQueue<int>();
            List<Thread> producers = new List<Thread>();
            int enqueueCount = 1000;
            int timeout = 1000;
            int dequeuedCount = 0;
            int numberOfProducers = 10;

            // Producer loop - post enqueueCount items to the queue
            ThreadStart producerThreadStart = new ThreadStart(
                delegate()
                {
                    for (int i = 0; i < enqueueCount; i++)
                    {
                        // Simulate doing some work
                        Thread.Sleep(1);

                        queue.Enqueue(i);
                    }
                });

            // Run multiple producer threads
            for (int i = 0; i < numberOfProducers; i++)
            {
                producers.Add(new Thread(producerThreadStart));
            }

            // Start all the producers
            producers.ForEach(p => p.Start());

            // Run the consumer on this thread
            // Stop when we time out
            int val;
            while (queue.Dequeue(out val, timeout))
            {
                dequeuedCount++;
            }

            // Wait for producers to complete
            producers.ForEach(p => p.Join());

            // Drain the queue - just in case we missed something
            while (queue.Dequeue(out val, timeout))
            {
                dequeuedCount++;
            }

            // We expect to have dequeued everything at this point
            Assert.AreEqual(numberOfProducers * enqueueCount, dequeuedCount);
        }
    }
}
